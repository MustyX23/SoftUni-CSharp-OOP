﻿namespace BirthdayCelebrations
{
    public interface IBirthable
    {
        string BirthDate { get; }
    }
}
