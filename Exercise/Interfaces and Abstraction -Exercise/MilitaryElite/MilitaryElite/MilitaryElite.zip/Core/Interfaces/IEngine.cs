﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
