﻿namespace Zoo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //...
            Lizard gushter = new Lizard("Hameleoncho");
            System.Console.WriteLine(gushter.Name);
        }
    }
}