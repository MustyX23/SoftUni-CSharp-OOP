﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VehiclesExtencion
{
    public interface IBus 
    {
        void DriveBus(double distance);
    }
}
