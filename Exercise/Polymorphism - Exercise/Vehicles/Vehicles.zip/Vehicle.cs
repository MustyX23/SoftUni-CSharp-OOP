﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public abstract class Vehicle
    {
        private double fuelQuantity;
        private double fuelConsumption;
        private double totalKilometres;
        private double totalLitersBurned;

        public Vehicle(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
            FuelConsumptionPerKm = fuelConsumption;
            TotalKilometres = 0;
            TotalLitersBurned = 0;
        }
        public double FuelConsumptionPerKm { get; set; }
        public double FuelQuantity
        {
            get { return fuelQuantity; }
            set { fuelQuantity = value; } 
        }
        public double FuelConsumption
        {
            get { return fuelConsumption; }
            set { fuelConsumption = value; }
        }
        public double TotalKilometres
        {
            get { return totalKilometres; }
            set { totalKilometres = value; }
        }
        public double TotalLitersBurned
        {
            get { return totalLitersBurned; }
            set { totalLitersBurned = value; }
        }
        //private double distance;
        //private double refuel;

        public abstract void Drive(double distance);
        public abstract void Refuel(double liters);
    }
}
