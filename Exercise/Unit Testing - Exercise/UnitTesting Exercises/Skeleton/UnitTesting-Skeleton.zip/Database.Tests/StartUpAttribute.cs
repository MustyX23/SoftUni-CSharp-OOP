﻿using System;

namespace Database.Tests
{
    internal class StartUpAttribute : Attribute
    {
    }
}