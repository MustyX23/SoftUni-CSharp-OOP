﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RobotService.Models
{
    public class LaserRadar : Supplement
    {
        public LaserRadar()
            : base(20082, 5000)
        {
        }
    }
}
