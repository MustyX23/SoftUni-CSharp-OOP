﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RobotService.Models
{
    public class SpecializedArm : Supplement
    {
        public SpecializedArm()
            : base(10045, 10000)
        {
        }
    }
}
