﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RobotService.Models
{
    public class IndustrialAssistant : Robot
    {
        public IndustrialAssistant(string model)
            : base(model, 40000, 5000)
        {
        }
    }
}
