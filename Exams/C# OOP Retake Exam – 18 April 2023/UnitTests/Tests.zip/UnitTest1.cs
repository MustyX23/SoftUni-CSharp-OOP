using NUnit.Framework;
using NUnit.Framework.Constraints;

namespace VehicleGarage.Tests
{
    public class Tests
    {
        private Vehicle vehicle;
        private Garage garage;

        [SetUp]
        public void Setup()
        {
            vehicle = new Vehicle("BMW", "M5", "7777");
            garage = new Garage(5);
        }

        [TearDown]
        public void TearDown()
        {
            vehicle = null;
        }
        [Test]
        public void Capacity_Check()
        {
            Garage garage = new Garage(0);
            bool actualResult = garage.AddVehicle(new Vehicle("Skuter", "912", "331"));
            Assert.IsFalse(actualResult);
        }
        [Test]
        public void CreatingVehicle()
        {
            vehicle = new Vehicle("BMW", "M5", "7777");

            Assert.AreEqual("BMW", vehicle.Brand);
            Assert.AreEqual("M5", vehicle.Model);
            Assert.AreEqual("7777", vehicle.LicensePlateNumber);
            Assert.AreEqual(100, vehicle.BatteryLevel);
            Assert.False(vehicle.IsDamaged);
        }
        [Test]
        public void GarageCount()
        {
            garage.AddVehicle(vehicle);
            Assert.AreEqual(1, garage.Vehicles.Count);
        }
        [Test]
        public void GarageCapacityShallRemain5()
        {
            Assert.AreEqual(5, garage.Capacity);            
        }
        [Test]
        public void AddVehicle_CapacityEqualsVehiclesCount()
        {
            Garage garage = new Garage(1);
            garage.AddVehicle(vehicle);
            Assert.False(garage.AddVehicle(new Vehicle("Honda", "Civic", "PA1242PR")));
        }
        [Test]
        public void AddVehicle_LicencePlateIsNotUnique()
        {
            garage.AddVehicle(vehicle);
            Assert.False(garage.AddVehicle(vehicle));
        }
        [Test]
        public void AddVehicleTest()
        {
            garage.AddVehicle(vehicle);
            Assert.AreEqual(1, garage.Vehicles.Count);
            Assert.True(garage.AddVehicle(new Vehicle("Honda", "Civic", "PA1242PR")));
        }
        [Test]
        public void ChargeVehicle_ToAHundredPercent()
        {
            garage.AddVehicle(vehicle);
            garage.DriveVehicle("7777", 50, false);
            int numbertOfChargedCars = garage.ChargeVehicles(51);

            Assert.AreEqual(1, numbertOfChargedCars);

        }
        [Test]
        public void ChargeVehicle_UnSuccessfull()
        {
            garage.AddVehicle(vehicle);
            garage.DriveVehicle("7777", 50, false);
            int numbertOfChargedCars = garage.ChargeVehicles(1);

            Assert.AreEqual(0, numbertOfChargedCars);
        }

        [Test]
        public void DriveVehicle_IsDamagedShallReturn()
        {
            Vehicle damagedVehicle = new Vehicle("Golf", "2ka", "PA2133BP");
            damagedVehicle.IsDamaged = true;
            garage.AddVehicle(damagedVehicle);

            garage.DriveVehicle("PA2133BP", 20, false);

            Assert.AreEqual(100, vehicle.BatteryLevel);
            Assert.IsTrue(vehicle.IsDamaged = true);
        }
        [Test]
        public void DriveVehicle_BatteryDrainageMoreThan_Hundred()
        {
            garage.AddVehicle(vehicle);
            garage.DriveVehicle("7777", 101, false);
            Assert.AreEqual(100, vehicle.BatteryLevel);
        }
        [Test]
        public void DriveVehicle_BatteryDrainage_MoreThan_BatteryLevel()
        {
            garage.AddVehicle(vehicle);
            garage.DriveVehicle("7777", 80, false);
            garage.DriveVehicle("7777", 30, false);
            Assert.AreEqual(20, vehicle.BatteryLevel);
        }
        [Test]
        public void DriveVehicle_AccidentOccured_DamagesTheVehicle()
        {
            garage.AddVehicle(vehicle);
            garage.DriveVehicle("7777", 50, true);
            Assert.AreEqual(50, vehicle.BatteryLevel);
            Assert.IsTrue(vehicle.IsDamaged);
        }
        [Test]
        public void DriveVehicleWithNoProblems()
        {
            garage.AddVehicle(vehicle);
            garage.DriveVehicle("7777", 50, false);

            Assert.AreEqual(50, vehicle.BatteryLevel);
            Assert.AreEqual("7777", vehicle.LicensePlateNumber);
            Assert.IsFalse(vehicle.IsDamaged);
        }
        [Test]
        public void RepairVehicles_ThereAreVehiclesToBe_Repaired()
        {
            Vehicle brokenVehicle = new Vehicle("Audi", "A3", "8888");
            garage.AddVehicle(brokenVehicle);
            garage.DriveVehicle("8888", 50, true);
            
            
            Assert.AreEqual($"Vehicles repaired: 1", garage.RepairVehicles());
            Assert.IsFalse(brokenVehicle.IsDamaged);

        }
        [Test]
        public void RepairVehicles_ThereAreNoVehiclesToBe_Repaired()
        {
            Vehicle notbrokenVehicle = new Vehicle("Audi", "A3", "8888");

            garage.AddVehicle(notbrokenVehicle);                                   
            Assert.AreEqual($"Vehicles repaired: 0", garage.RepairVehicles());
            Assert.IsFalse(notbrokenVehicle.IsDamaged);
        }

    }
}