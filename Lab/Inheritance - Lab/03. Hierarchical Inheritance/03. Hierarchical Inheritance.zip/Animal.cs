﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    public class Animal
    {
        //Animal with a single public method Eat() that prints: "eating…"
        public void Eat()
        {
            Console.WriteLine("eating…");
        }
    }
}
